---
Installing this Miscellaneous project by @seanpm2001
---

<!--

This project currently doesn't have to be installed to be viewed, and currently doesn't require installation, it is a basic website project that is compliant with web standards, so it should work in any web browser that respects WHATWG.

If you want to load the web pages, you will need to have an HTML5 framework installed (version 5.0 or higher) and the packages for any programming languages included.

The current included languages include:

None (v1)

If you want to view the image files, the majority of files are in JPG format. Make sure your computer can handle images of 2560x1440/2560x1080 resolution well, and that your computer can handle JPG files.

Some image files are in other formats, such as SVG, and PNG. You will need support for viewing these files to view these files.

Some included files are in Markdown format (*.md) for best viewing, you should use a markdown viewer/markdown editor.

Some included files are in PDF format. They should be opened with a document viewer capable of handling PDF documents.
!-->

Install instructions need to be added manually.

---
Install instructions file version: 1 (Monday, August 23rd 2021 at 6:31 pm)
---
